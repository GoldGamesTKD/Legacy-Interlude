INSERT INTO `accounts` (`login`,`password`,`lastactive`,`accessLevel`,`lastIP`,`lastHWID`,`lastServerId`,`ban_expire`,`allow_ip`,`l2email`,`privatekey`) VALUES
('tkd1','EOwEfKfYOFaHtGzdbK/rhstY0fMIno0bgatSz+DlnKlcD+zZkqEUDVlcrvCHV8dwbvDts3lFj++wLiJk6jEdag==','1722557055','0','127.0.0.1','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('chupador','XUXYo38WmYmAOcBuwJUczOHrG5N9/vmBSR+aQInMAutgQAtQt2kU0TprRwm/uUehRzVTXVtH79xemdi2xgWKOQ==','1711900414','0','192.168.178.94','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('dominator','v4l8pXHWesuF605H4A9PpObOydv2SYe286gsaO85xYAEeYUujJbLUWeNblvmp6n8yFax8hSZ+5BDaCWerjAK8A==','1711959337','0','192.168.178.94','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('elfarcher','TzXfX76zXk44ZfKhDEe8dZj2RLuoe+0io9F42a0wVJIA0zvOsB5Za2PriW1fRoVIH4vuxY0CAkUcCnwNhYvPaQ==','1711964911','0','192.168.178.94','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('razor','AHRTIChcx2dD9XWR07j3kYXgT7lOWsRU1ff0dWoW1rjXZLIA+JUbLSE6SXLBY3E7P55cked1IzzkmXnLgecyyg==','1712186350','0','177.155.220.72','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('tkd2','JvVcRUOEMTP0Wg7bscX3AY/0gMM98DbTn7RIjTSJNYZe9uqwaVm5xWjKacGjp4EErCiESTzuVBx17BTCNhbuuQ==','1712181622','0','192.168.178.1','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('krauzer','r5LCFMzQfwPiLxS8iAixJRDQ5jw3vx0nBzZDdn1fRYmuS1e3XWWPnW7qU4giVsCVlx8iG+Opan3VQQIOjTVeYg==','1712868310','0','170.231.209.196','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('razor10','AHRTIChcx2dD9XWR07j3kYXgT7lOWsRU1ff0dWoW1rjXZLIA+JUbLSE6SXLBY3E7P55cked1IzzkmXnLgecyyg==','1712186325','0','177.155.220.72','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null'),
('admtkd','+TMzU/lM9vyYuUdnBkvx2mXT0Jl+dFW0v3Bq1S0IGJ5stpnHf/QB0cHllq6J9EG06DSNk2FOMcOektH6+/5ONA==','1722556530','0','127.0.0.1','4ae71336e44bf9bf79d2752e234818a5','1','0','','null','null');
