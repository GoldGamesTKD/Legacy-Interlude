INSERT INTO `character_quests` (`char_id`,`name`,`var`,`value`) VALUES
('268477111','_255_Tutorial','<state>','Started'),
('268477111','_255_Tutorial','tutorial_quest','5'),
('268477111','_255_Tutorial','tutorial_quest_ex','4'),
('268477111','_206_DwarfTutorial','<state>','Started');
