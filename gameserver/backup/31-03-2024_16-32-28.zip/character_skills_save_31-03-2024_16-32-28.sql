INSERT INTO `character_skills_save` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`,`end_time`,`reuse_delay_org`) VALUES
('268477111','60018','1','117','1711898123006','0'),
('268477111','7029','4','117','1711897834489','0');
