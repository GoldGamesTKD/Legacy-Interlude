INSERT INTO `cursed_weapons` (`item_id`,`player_id`,`player_karma`,`player_pkkills`,`nb_kills`,`x`,`y`,`z`,`end_time`) VALUES
('8689','0','0','0','0','43667','248539','-6496','1723154105'),
('8190','0','0','0','0','14058','117848','-12088','1723330168');
