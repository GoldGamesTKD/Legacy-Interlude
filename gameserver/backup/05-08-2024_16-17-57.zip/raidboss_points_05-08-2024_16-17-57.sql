INSERT INTO `raidboss_points` (`owner_id`,`boss_id`,`points`) VALUES
('268536948','25360','343');
