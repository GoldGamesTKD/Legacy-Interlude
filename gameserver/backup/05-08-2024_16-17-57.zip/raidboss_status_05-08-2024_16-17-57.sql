INSERT INTO `raidboss_status` (`id`,`current_hp`,`current_mp`,`respawn_delay`) VALUES
('25357','0','0','1722814441'),
('25372','0','0','1722815240'),
('25128','0','0','1722821207'),
('25360','0','0','1722863148');
