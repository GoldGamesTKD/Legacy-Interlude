INSERT INTO `character_status_bonuses` (`char_obj_id`,`class_index`,`bonus_points`,`elixir_points`,`used_elixir_points`,`str`,`con`,`dex`,`int`,`wit`,`men`) VALUES
('268477111','53','84','0','0','0','0','6','0','0','0'),
('268477111','117','83','0','0','57','0','0','0','0','0'),
('268544175','49','13','0','0','0','0','0','0','10','0');
