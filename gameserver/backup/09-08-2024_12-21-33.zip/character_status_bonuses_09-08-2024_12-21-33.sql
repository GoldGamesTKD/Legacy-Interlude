INSERT INTO `character_status_bonuses` (`char_obj_id`,`class_index`,`bonus_points`,`elixir_points`,`used_elixir_points`,`str`,`con`,`dex`,`int`,`wit`,`men`) VALUES
('268549759','25','81','0','0','0','0','3','0','0','0');
