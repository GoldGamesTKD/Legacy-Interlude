INSERT INTO `character_subclasses` (`char_obj_id`,`class_id`,`level`,`exp`,`sp`,`curHp`,`curMp`,`curCp`,`maxHp`,`maxMp`,`maxCp`,`active`,`isBase`,`death_penalty`) VALUES
('268549759','25','80','4200000000','95','1720.0','1312.0','860.0','1720','1312','860','1','1','0');
