INSERT INTO `character_macroses` (`char_obj_id`,`id`,`icon`,`name`,`descr`,`acronym`,`commands`) VALUES
('268549759','1000','104','ADMIN','','ADMI','3,0,0,//admin;');
