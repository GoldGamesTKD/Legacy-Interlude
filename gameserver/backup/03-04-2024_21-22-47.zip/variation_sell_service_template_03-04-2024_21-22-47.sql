INSERT INTO `variation_sell_service_template` (`menuId`,`variationOption1`,`variationOption2`,`consumeList`) VALUES
('1','14561','700','4037-10'),
('2','14562','700','4037-10'),
('3','14563','700','4037-10'),
('4','14564','700','4037-10'),
('5','14565','700','4037-10'),
('6','14566','700','4037-10');
