INSERT INTO `global_tasks` (`id`,`task`,`type`,`last_activation`,`param1`,`param2`,`param3`) VALUES
('1','sp_recommendations','TYPE_GLOBAL_TASK','1711972800','1','13:00:00','');
