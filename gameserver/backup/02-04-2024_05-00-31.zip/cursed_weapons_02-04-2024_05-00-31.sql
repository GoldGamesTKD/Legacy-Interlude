INSERT INTO `cursed_weapons` (`item_id`,`player_id`,`player_karma`,`player_pkkills`,`nb_kills`,`x`,`y`,`z`,`end_time`) VALUES
('8689','0','0','0','0','27332','119762','-3696','1712276190'),
('8190','0','0','0','0','18155','117702','-3680','1712428601');
