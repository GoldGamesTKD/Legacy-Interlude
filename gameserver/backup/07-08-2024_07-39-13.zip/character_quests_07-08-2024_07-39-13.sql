INSERT INTO `character_quests` (`char_id`,`name`,`var`,`value`) VALUES
('268546708','_255_Tutorial','tutorial_quest','4');
