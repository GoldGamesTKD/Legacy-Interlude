INSERT INTO `character_skills` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`) VALUES
('268552329','1320','6','1'),
('268546708','1320','4','44');
