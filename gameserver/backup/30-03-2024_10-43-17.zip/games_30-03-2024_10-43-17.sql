INSERT INTO `games` (`id`,`idnr`,`number1`,`number2`,`prize`,`newprize`,`prize1`,`prize2`,`prize3`,`enddate`,`finished`) VALUES
('1','1','0','0','50000','50000','0','0','0','1.711908000688E12','0');
