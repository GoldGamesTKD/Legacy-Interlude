INSERT INTO `character_quests` (`char_id`,`name`,`var`,`value`) VALUES
('268546708','_255_Tutorial','tutorial_quest','4'),
('268538260','_255_Tutorial','<state>','Started'),
('268538260','_255_Tutorial','tutorial_quest','1'),
('268538260','_255_Tutorial','tutorial_quest_ex','-5'),
('268538385','_255_Tutorial','<state>','Started'),
('268538385','_255_Tutorial','tutorial_quest','1'),
('268538385','_255_Tutorial','tutorial_quest_ex','-5'),
('268538840','_255_Tutorial','<state>','Started'),
('268538840','_255_Tutorial','tutorial_quest','2'),
('268538840','_255_Tutorial','tutorial_quest_ex','-5'),
('268538899','_255_Tutorial','<state>','Started'),
('268538899','_255_Tutorial','tutorial_quest','2'),
('268538899','_255_Tutorial','tutorial_quest_ex','-5');
