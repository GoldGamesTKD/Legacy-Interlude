INSERT INTO `server_variables` (`name`,`value`) VALUES
('oly_season_id','4'),
('gamed_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('variation_sell_service_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('pawnshop_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('oly_season_calc','false'),
('@OlyPartCnt','0'),
('ManorApproved','false'),
('fishChampionshipEnd','1722967200149'),
('monster_race','1648'),
('maxTotalOnline','2'),
('oly_chero_season','3'),
('promocode_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7');
