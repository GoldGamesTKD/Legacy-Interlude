INSERT INTO `character_macroses` (`char_obj_id`,`id`,`icon`,`name`,`descr`,`acronym`,`commands`) VALUES
('268477043','1000','6','ADMIN','','ADMI','3,0,0,//admin;');
