INSERT INTO `server_variables` (`name`,`value`) VALUES
('oly_season_id','1'),
('gamed_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('variation_sell_service_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('oly_season_calc','false'),
('@OlyPartCnt','0'),
('ManorApproved','false'),
('fishChampionshipEnd','1711479600960'),
('monster_race','15'),
('maxTotalOnline','1');
