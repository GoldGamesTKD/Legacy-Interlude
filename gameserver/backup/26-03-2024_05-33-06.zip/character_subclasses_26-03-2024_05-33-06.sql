INSERT INTO `character_subclasses` (`char_obj_id`,`class_id`,`level`,`exp`,`sp`,`curHp`,`curMp`,`curCp`,`maxHp`,`maxMp`,`maxCp`,`active`,`isBase`,`death_penalty`) VALUES
('268477043','53','2','87','6','154.0','46.0','108.0','154','46','108','1','1','0');
