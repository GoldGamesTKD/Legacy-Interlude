INSERT INTO `character_skills` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`) VALUES
('268477043','194','1','53'),
('268477043','1320','1','53');
