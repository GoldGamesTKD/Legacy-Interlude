INSERT INTO `character_macroses` (`char_obj_id`,`id`,`icon`,`name`,`descr`,`acronym`,`commands`) VALUES
('268544779','1000','104','//admin','','//ad','3,0,0,//admin;'),
('268544779','1001','44','//reload','llreload','//re','3,0,0,//reload;');
