INSERT INTO `server_variables` (`name`,`value`) VALUES
('oly_season_id','1'),
('gamed_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('promocode_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('variation_sell_service_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('pawnshop_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('oly_season_calc','false'),
('@OlyPartCnt','0'),
('ManorApproved','true'),
('fishChampionshipEnd','1723572000414'),
('maxTotalOnline','2'),
('monster_race','72');
