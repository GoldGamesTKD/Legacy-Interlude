INSERT INTO `character_variables` (`obj_id`,`type`,`name`,`value`,`expire_time`) VALUES
('268544779','user-var','lang@','en','-1'),
('268544779','user-var','noCarrier','0','-1'),
('268544784','user-var','lang@','en','-1'),
('268544784','user-var','noCarrier','0','-1'),
('268544784','user-var','QUEST_STATE_OF_255_ADENA_GIVEN','true','-1'),
('268544784','user-var','ExpandInventory','170','-1'),
('268544784','user-var','titlecolor','7c49fc','-1'),
('268544784','user-var','namecolor','7c49fc','-1'),
('268544784','user-var','HPACPEnabled','true','-1'),
('268544784','user-var','CPACPEnabled','true','-1'),
('268544784','user-var','MPACPEnabled','true','-1'),
('268544784','user-var','HPACPActPercent','90','-1'),
('268544784','user-var','BuffProf-0','18;23;15;20;12;40;37;3;21;14;34;31;2;7;36;4;16;8;22;19;104;105;35;25;11;9;27;5;41;13;32;17;10;24;29;38;26;33;106;103;69;99924;72;74;76;78;80;83;71;73;75;77;79;82;84;85;87;89;92;94;91;95;93;90;88;86;86','-1');
