INSERT INTO `character_subclasses` (`char_obj_id`,`class_id`,`level`,`exp`,`sp`,`curHp`,`curMp`,`curCp`,`maxHp`,`maxMp`,`maxCp`,`active`,`isBase`,`death_penalty`) VALUES
('268477111','117','80','4200264710','235854','7174.0','1645.0','4593.0','7174','1645','4593','1','1','0'),
('268477171','49','1','29','2','97.3368','88.2504','52.0','104','89','52','1','1','0');
