INSERT INTO `character_quests` (`char_id`,`name`,`var`,`value`) VALUES
('268544779','_255_Tutorial','<state>','Started'),
('268544779','_255_Tutorial','tutorial_quest','1'),
('268544779','_255_Tutorial','tutorial_quest_ex','-4');
