INSERT INTO `character_skills` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`) VALUES
('268544779','1320','1','53'),
('268544779','194','1','53');
