INSERT INTO `items` (`item_id`,`owner_id`,`item_type`,`amount`,`location`,`slot`,`enchant`) VALUES
('268544780','268544779','5588','1','INVENTORY','0','0'),
('268544781','268544779','1147','1','PAPERDOLL','11','0'),
('268544782','268544779','1146','1','PAPERDOLL','6','0'),
('268544783','268544779','2370','1','PAPERDOLL','5','0');
