INSERT INTO `character_subclasses` (`char_obj_id`,`class_id`,`level`,`exp`,`sp`,`curHp`,`curMp`,`curCp`,`maxHp`,`maxMp`,`maxCp`,`active`,`isBase`,`death_penalty`) VALUES
('268544779','53','1','0','0','133.0','39.0','75.0749','133','39','93','1','1','0');
