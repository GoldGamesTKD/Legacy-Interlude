INSERT INTO `character_variables` (`obj_id`,`type`,`name`,`value`,`expire_time`) VALUES
('268544779','user-var','lang@','en','-1'),
('268544779','user-var','noCarrier','0','-1');
