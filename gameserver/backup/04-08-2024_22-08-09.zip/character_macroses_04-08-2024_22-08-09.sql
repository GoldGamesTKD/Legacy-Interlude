INSERT INTO `character_macroses` (`char_obj_id`,`id`,`icon`,`name`,`descr`,`acronym`,`commands`) VALUES
('268544787','1000','90046568','ADMIN','','ADMI','3,0,0,//admin;');
