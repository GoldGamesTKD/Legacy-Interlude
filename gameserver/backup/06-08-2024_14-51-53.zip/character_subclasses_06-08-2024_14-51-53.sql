INSERT INTO `character_subclasses` (`char_obj_id`,`class_id`,`level`,`exp`,`sp`,`curHp`,`curMp`,`curCp`,`maxHp`,`maxMp`,`maxCp`,`active`,`isBase`,`death_penalty`) VALUES
('268544779','53','40','15422851','0','1136.0','376.0','795.0','1136','376','795','1','1','0'),
('268544784','23','51','47366201','2286864','3820.7293','556.3175','773.0','4070','1021','773','1','1','0');
