INSERT INTO `character_status_bonuses` (`char_obj_id`,`class_index`,`bonus_points`,`elixir_points`,`used_elixir_points`,`str`,`con`,`dex`,`int`,`wit`,`men`) VALUES
('268544779','53','41','0','0','0','0','0','0','0','0'),
('268544784','18','41','0','0','0','0','41','0','0','0'),
('268544784','23','52','0','0','0','0','51','0','0','0');
