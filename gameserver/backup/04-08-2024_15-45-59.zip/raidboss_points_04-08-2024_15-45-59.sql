INSERT INTO `raidboss_points` (`owner_id`,`boss_id`,`points`) VALUES
('268544214','25357','395');
