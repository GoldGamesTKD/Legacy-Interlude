INSERT INTO `raidboss_status` (`id`,`current_hp`,`current_mp`,`respawn_delay`) VALUES
('25357','0','0','1712073757');
