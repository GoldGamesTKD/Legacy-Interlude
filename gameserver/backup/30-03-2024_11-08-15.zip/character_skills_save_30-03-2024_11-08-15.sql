INSERT INTO `character_skills_save` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`,`end_time`,`reuse_delay_org`) VALUES
('268477043','7029','4','53','1711795997068','0');
