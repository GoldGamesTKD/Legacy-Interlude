INSERT INTO `character_status_bonuses` (`char_obj_id`,`class_index`,`bonus_points`,`elixir_points`,`used_elixir_points`,`str`,`con`,`dex`,`int`,`wit`,`men`) VALUES
('268477043','53','89','0','0','7','0','8','5','0','0');
