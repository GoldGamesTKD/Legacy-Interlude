INSERT INTO `character_macroses` (`char_obj_id`,`id`,`icon`,`name`,`descr`,`acronym`,`commands`) VALUES
('268477111','1000','104','//admin','','//ad','3,0,0,//admin;');
