INSERT INTO `raidboss_status` (`id`,`current_hp`,`current_mp`,`respawn_delay`) VALUES
('25357','0','0','1712073757'),
('25146','0','0','1712060246'),
('25360','0','0','1712038475'),
('25001','0','0','1712052174');
