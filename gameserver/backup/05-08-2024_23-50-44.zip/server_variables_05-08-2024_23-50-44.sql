INSERT INTO `server_variables` (`name`,`value`) VALUES
('monster_race','1922'),
('oly_season_id','4'),
('oly_season_calc','false'),
('@OlyPartCnt','0'),
('maxTotalOnline','7'),
('fishChampionshipEnd','1722967200149'),
('gamed_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('promocode_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('variation_sell_service_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('pawnshop_dbmsstruct_dbver','0493bafd00056a3bee9c83b4edae42f7'),
('ManorApproved','false');
