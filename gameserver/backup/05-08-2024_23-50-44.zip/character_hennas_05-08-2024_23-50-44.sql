INSERT INTO `character_hennas` (`char_obj_id`,`symbol_id`,`slot`,`class_index`) VALUES
('268545187','144','1','40'),
('268545187','139','2','40'),
('268545187','135','3','40');
