INSERT INTO `raidboss_status` (`id`,`current_hp`,`current_mp`,`respawn_delay`) VALUES
('25357','90169','455','0'),
('25146','90169','455','0'),
('25360','107186','606','0'),
('25001','95986','514','0');
