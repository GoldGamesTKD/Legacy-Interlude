INSERT INTO `character_skills_save` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`,`end_time`,`reuse_delay_org`) VALUES
('268477171','1001','1','49','1711900550659','0'),
('268544175','60018','1','49','1711901652455','0'),
('268544175','1001','1','49','1711901630794','0');
