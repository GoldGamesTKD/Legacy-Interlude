INSERT INTO `character_quests` (`char_id`,`name`,`var`,`value`) VALUES
('268477043','_255_Tutorial','<state>','Started'),
('268477043','_255_Tutorial','tutorial_quest','4'),
('268477043','_255_Tutorial','tutorial_quest_ex','3'),
('268477043','_206_DwarfTutorial','<state>','Started');
