INSERT INTO `character_subclasses` (`char_obj_id`,`class_id`,`level`,`exp`,`sp`,`curHp`,`curMp`,`curCp`,`maxHp`,`maxMp`,`maxCp`,`active`,`isBase`,`death_penalty`) VALUES
('268477111','117','80','4200000000','64','4001.088','1246.3418','3256.6953','6249','1645','4374','1','1','0');
