INSERT INTO `character_variables` (`obj_id`,`type`,`name`,`value`,`expire_time`) VALUES
('268477111','user-var','lang@','en','-1'),
('268477111','user-var','QUEST_STATE_OF_255_ADENA_GIVEN','true','-1'),
('268477111','user-var','gm_vis','true','-1'),
('268477111','user-var','QUEST_STATE_OF_255_TUTORIAL_VOICE_0','true','-1'),
('268477111','user-var','QUEST_STATE_OF_255_TUTORIAL_VOICE_1','true','-1'),
('268477111','user-var','QUEST_STATE_OF_255_BLUE_GEM_GIVEN','true','-1');
