INSERT INTO `oly_nobles` (`char_id`,`class_id`,`char_name`,`points_current`,`points_past`,`points_pre_past`,`class_free_cnt`,`class_based_cnt`,`team_cnt`,`comp_win`,`comp_loose`,`comp_done`,`comp_done_past`) VALUES
('268544196','95','karma','18','0','0','0','0','0','0','0','0','0');
