INSERT INTO `character_quests` (`char_id`,`name`,`var`,`value`) VALUES
('268536373','_255_Tutorial','<state>','Started'),
('268607143','_255_Tutorial','<state>','Started'),
('268536948','_255_Tutorial','<state>','Started'),
('268536373','_255_Tutorial','tutorial_quest','0'),
('268541639','_255_Tutorial','<state>','Started'),
('268541639','_255_Tutorial','tutorial_quest','1'),
('268541639','_255_Tutorial','tutorial_quest_ex','-5');
