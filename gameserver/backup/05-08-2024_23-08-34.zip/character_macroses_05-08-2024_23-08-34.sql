INSERT INTO `character_macroses` (`char_obj_id`,`id`,`icon`,`name`,`descr`,`acronym`,`commands`) VALUES
('268536948','1000','104','asda','','asda','3,0,0,//admin;'),
('268541639','1000','104','//ADMIN','','//AD','3,0,0,//admin;');
