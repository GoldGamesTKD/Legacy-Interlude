INSERT INTO `character_variables` (`obj_id`,`type`,`name`,`value`,`expire_time`) VALUES
('268544228','user-var','HPACPEnabled','true','-1'),
('268544228','user-var','CPACPEnabled','true','-1'),
('268544228','user-var','MPACPEnabled','true','-1'),
('268544228','user-var','HPACPActPercent','90','-1'),
('268544217','user-var','MPACPEnabled','true','-1'),
('268544196','user-var','CustomHeroEndTime','1722908175','-1'),
('268544217','user-var','CustomHeroEndTime','1722908578','-1'),
('268544217','user-var','ExpandInventory','23','-1'),
('268545187','user-var','ExpandInventory','170','-1'),
('268544322','user-var','ExpandInventory','170','-1'),
('268545187','user-var','packageselllist','268562048;5;1000000000:','-1'),
('268544228','user-var','ExpandInventory','170','-1'),
('268544787','user-var','gm_vis','true','-1');
