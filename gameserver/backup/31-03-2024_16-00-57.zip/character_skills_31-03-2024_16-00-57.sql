INSERT INTO `character_skills` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`) VALUES
('268477111','194','1','53'),
('268477111','1320','2','53'),
('268477111','239','1','53');
