INSERT INTO `raidboss_points` (`owner_id`,`boss_id`,`points`) VALUES
('268544175','25357','754');
