INSERT INTO `cursed_weapons` (`item_id`,`player_id`,`player_karma`,`player_pkkills`,`nb_kills`,`x`,`y`,`z`,`end_time`) VALUES
('8689','0','0','0','0','11821','113766','-9064','1723314173');
