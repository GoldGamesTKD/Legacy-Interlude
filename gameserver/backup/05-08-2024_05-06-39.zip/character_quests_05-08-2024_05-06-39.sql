INSERT INTO `character_quests` (`char_id`,`name`,`var`,`value`) VALUES
('268544217','_255_Tutorial','tutorial_quest','2'),
('268545187','_255_Tutorial','tutorial_quest','2'),
('268544217','_255_Tutorial','tutorial_quest_ex','-5'),
('268544196','_255_Tutorial','tutorial_quest','2'),
('268544242','_255_Tutorial','tutorial_quest','1'),
('268544322','_255_Tutorial','tutorial_quest','4'),
('268544228','_255_Tutorial','tutorial_quest','4');
