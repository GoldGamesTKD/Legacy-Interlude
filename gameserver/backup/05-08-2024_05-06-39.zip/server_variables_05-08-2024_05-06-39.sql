INSERT INTO `server_variables` (`name`,`value`) VALUES
('monster_race','1817'),
('oly_season_id','4'),
('oly_season_calc','false'),
('@OlyPartCnt','0'),
('maxTotalOnline','7'),
('fishChampionshipEnd','1722967200149');
