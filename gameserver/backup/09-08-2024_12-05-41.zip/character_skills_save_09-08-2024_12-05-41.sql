INSERT INTO `character_skills_save` (`char_obj_id`,`skill_id`,`skill_level`,`class_index`,`end_time`,`reuse_delay_org`) VALUES
('268549759','1177','1','25','1723197637646','5176');
