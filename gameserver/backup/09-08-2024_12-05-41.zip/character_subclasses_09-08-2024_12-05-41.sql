INSERT INTO `character_subclasses` (`char_obj_id`,`class_id`,`level`,`exp`,`sp`,`curHp`,`curMp`,`curCp`,`maxHp`,`maxMp`,`maxCp`,`active`,`isBase`,`death_penalty`) VALUES
('268549759','25','5','3360','95','155.0','132.0','77.0','155','132','77','1','1','0');
